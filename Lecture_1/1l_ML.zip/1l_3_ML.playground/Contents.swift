import UIKit
/*
 authors: M.Li
 number: +77013610104
 */

var dep:Float = 1000
var per:Float = 15
var year:Int = 5

for i in 0...year-1 {
    dep = dep * (per/100 + 1)
    print("В \(i+1) год будет \(dep)")
}
