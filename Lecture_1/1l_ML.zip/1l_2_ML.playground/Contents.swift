import UIKit
/*
 authors: M.Li
 number: +77013610104
 */

var a:Float = 3
var b:Float = 4

var s:Float, p:Float, c:Float

c = pow(pow(a, 2)+pow(b, 2), 0.5)
s = a*b/2
p = a+b+c

print("Гипотенуза равна \(c), периметр равен \(p), площадь равна \(s)")
